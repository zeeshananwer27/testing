<div class="slider-banner">
    @include('public.home.sections.partials.single_banner', ['banner' => $sliderBanners[1]])
    @include('public.home.sections.partials.single_banner', ['banner' => $sliderBanners[2]])
</div>
