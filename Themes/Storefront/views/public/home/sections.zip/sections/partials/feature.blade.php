<div class="col-lg-3 col-sm-6">
    <div class="single-feature">
        <div class="feature-icon pull-left">
            <i class="fa {{ $feature['icon'] }}" aria-hidden="true"></i>
        </div>

        <div class="feature-details">
            <h4>{{ $feature['title'] }}</h4>
            <p>{{ $feature['subtitle'] }}</p>
        </div>
    </div>
</div>
