/*
 * Global Variables
 *      These variables are accessible in this whole file.
 */
var rows = 0;
var columns = 0;
var nodeDataArray = [];
var selectedNodesTable = {};
var rotatableNodeKey = undefined;
var rotatableNodePosition = undefined;
var wereNodesDupByUser = false;
var wereNodesDelByUser = false;
var angle = 0;
var rotatableNodeKey = undefined;

/*
 * init() function is the main function.
 *      Background is initialized here for all diagrams in this file.
 */
function init() {
    if (window.goSamples) goSamples();
    var $ = go.GraphObject.make;

    myDiagram = $(
        go.Diagram,
        "myDiagramDiv",
        {
            initialAutoScale: go.Diagram.Uniform,
            "draggingTool.isCopyEnabled": false,
            "undoManager.isEnabled": true
        }
    );

    myDiagram.grid.visible = true;

}

/***************************************** Handlers/Controllers*******************************************/
/*********************************************************************************************************/

function Handler__NewDiagram({ hideMenu = "" }) {
    var section = document.getElementById("Section");
    var diagramCategory = section.options[section.selectedIndex].value;

    switch (diagramCategory) {
        case "AssignedSeating":
            console.log("AssignedSeating");

            var rows = Helpers__GetInputFieldValue({ elementID: "getRows" });
            var columns = Helpers__GetInputFieldValue({ elementID: "getColumns" });
            if (rows > 160 || columns > 160)
                return;

            // var newNode = Model__AssignedSeating({ rows: rows, columns: columns });
            // this.nodeDataArray.push(Model__AssignedSeating({ rows: rows, columns: columns }));
            // this.nodeDataArray = Helpers__filterUndefinedFromArray({ array: this.nodeDataArray });

            myDiagram.nodeTemplateMap.add(
                "AssignedSeating",
                Shape__AssignedSeating()
            );

            // myDiagram.model.addNodeData(newNode);
            // myDiagram.model = new go.GraphLinksModel(this.nodeDataArray);
            myDiagram.model.addNodeData(Model__AssignedSeating({ rows: rows, columns: columns }));

            Helpers__HideOrShow({ elementID: hideMenu });
            Helpers__SetInputFieldValue({ elementID: "getRows", value: "" });
            Helpers__SetInputFieldValue({ elementID: "getColumns", value: "" });
            Helpers__clearSelectedNodesTable();

            break;
        case "GeneralAdmission":
            console.log("GeneralAdmission");

            var capacity = Helpers__GetInputFieldValue({ elementID: "getCapacity" });

            var newNode = Model__GeneralAdmission({ capacity: capacity });

            myDiagram.nodeTemplateMap.add(
                "GeneralAdmission",
                Shape__GeneralAdmission()
            );

            myDiagram.model.addNodeData(newNode);
            // myDiagram.model.addNodeData(newNode);

            Helpers__HideOrShow({ elementID: hideMenu });
            Helpers__SetInputFieldValue({ elementID: "getCapacity", value: "" });
            Helpers__clearSelectedNodesTable();

            break;
        default:
            console.log("Default case: -------------------");
    };

    myDiagram.toolManager.rotatingTool.handleAngle = 90;

}

function Handler__RemoveSelectedDiagram() {
    var array = Helpers__DuplicateArray({ nodeDataArray: myDiagram.model.Fc });
    array.map((item) => {
        if (this.selectedNodesTable[item.key] !== undefined) {
            myDiagram.model.removeNodeData(item);
        }
    });
}

function Handler__DuplicateSelectedDiagram() {
    var array = Helpers__DuplicateArray({ nodeDataArray: myDiagram.model.Fc });

    array.map((item) => {
        if (this.selectedNodesTable[item.key] !== undefined) {
            switch (item.category) {
                case "AssignedSeating":
                    myDiagram.model.addNodeData({
                        category: item.category,
                        angle: item.angle,
                        seat: item.seat,
                        nodeDataArray: item.nodeDataArray
                    });
                    var length = myDiagram.model.Fc.length;
                    length = length - 1;
                    var groupKey = myDiagram.model.Fc[length].key;

                    Helpers__GenerateSeats({ nodeDataArray: myDiagram.model.Fc, oldGroupKey: item.key, newGroupKey: groupKey });
                    break;
                case "GeneralAdmission":
                    myDiagram.model.addNodeData({
                        foot: item.foot,
                        category: item.category,
                        seat: item.seat,
                        capacity: item.capacity,
                        capacityValue: item.capacityValue,
                        img: item.img,
                        color: item.color,
                        angle: item.angle
                    });
                    break;
                default:
                    break;
            }
        }
    });
}

function Handler__onRotateDiagram({ angle = 0 }) {
    var group = myDiagram.model.findNodeDataForKey(this.rotatableNodeKey);
    group.angle = angle;
    myDiagram.model.updateTargetBindings(group);

}

/***************************************** Shapes/Views **************************************************/
/*********************************************************************************************************/

function Shape__AssignedSeating() {
    var $ = go.GraphObject.make;

    return $(go.Node, "Horizontal",
        {
            cursor: "pointer",
            selectionAdorned: true,  // don't bother with any selection adornment
            selectionChanged: Helpers__onSelectNode,
            locationSpot: go.Spot.Center
        },  // executed when Part.isSelected has changed
        // new go.Binding("location", "location", go.Point.parse).makeTwoWay(go.Point.stringify),
        new go.Binding("angle", "angle").makeTwoWay(),
        $(go.Shape, "Circle", { fill: "lightgray" }),
        new go.Binding("itemArray", "nodeDataArray"),
        {
            itemTemplate:
                $(go.Panel, "Table",
                    new go.Binding("itemArray", "people"),
                    { // the rows for the people
                        defaultAlignment: go.Spot.Center,
                        defaultColumnSeparatorStroke: "transparent",
                        itemTemplate:  // bound to a person/row data object
                            $(go.Panel, "TableRow",
                                // which in turn consists of a collection of cell objects,
                                // held by the "columns" property in an Array
                                new go.Binding("itemArray", "columns"),
                                // you could also have other Bindings here for the whole row
                                {
                                    itemTemplate:  // bound to a cell object
                                        $(go.Panel,  // each of which as "attr" and "text" properties
                                            "Auto",
                                            // { stretch: go.GraphObject.Fill, alignment: go.Spot.Center },
                                            new go.Binding("column", "column",
                                                // a is the attr value. Like name, phone, office
                                                function (a, elt) {  // ELT is this bound item/cell Panel
                                                    // elt.data will be the cell object
                                                    // elt.panel.data will be the person/row data object
                                                    // elt.part.data will be the node data object
                                                    // "columnDefinitions" is on the node data object, so:
                                                    // console.log("elt.part.data: ", elt.part.data, "a", a);
                                                    var cd = Helpers__findColumnDefinition({ nodeData: elt.part.data, column: a });
                                                    // cd = columnDefinition
                                                    if (cd !== null) return cd.column;
                                                    throw new Error("unknown column name: " + a);
                                                }
                                            ),
                                            $(
                                                go.Shape, "Circle",
                                                {
                                                    desiredSize: new go.Size(50, 50), fill: "#d1d1d1", strokeWidth: 5, stroke: 'transparent'
                                                },
                                            ),
                                            $(go.TextBlock,
                                                // { margin: new go.Margin(2, 2, 0, 2), wrap: go.TextBlock.None },
                                                new go.Binding("text")
                                            )
                                        )
                                }
                            )
                    }
                )
        }
    )
}

function Shape__GeneralAdmission() {
    var $ = go.GraphObject.make;

    return $(go.Node, "Auto",
        {
            resizable: true,    // the Shape will go around the TextBlock
            selectionAdorned: true,
            desiredSize: new go.Size(250, 170),
            selectionChanged: Helpers__onSelectNode,
            locationSpot: go.Spot.Center
        },
        new go.Binding("location", "location", go.Point.parse).makeTwoWay(go.Point.stringify),
        // save the modified size in the model node data
        new go.Binding("desiredSize", "size", go.Size.parse).makeTwoWay(go.Size.stringify),
        new go.Binding("angle", "angle").makeTwoWay(),
        $(go.Shape, "RoundedRectangle", { strokeWidth: 0 },
            // Shape.fill is bound to Node.data.color
            new go.Binding("fill", "color")),
        $(go.Panel, "Vertical",
            $(go.Picture,
                {
                    maxSize: new go.Size(50, 50),
                },
                new go.Binding("source", "img")),
            $(go.TextBlock,
                {
                    margin: new go.Margin(3, 0, 0, 0),
                    font: "bold 10pt sans-serif",
                },
                new go.Binding("text", "foot")),
            $(go.Panel, "Horizontal", $(go.TextBlock,
                {
                    margin: new go.Margin(3, 0, 0, 0),
                    isMultiline: false
                },
                new go.Binding("text", "capacity")), $(go.TextBlock,
                    {
                        margin: new go.Margin(0, 0, 0, 0),
                        font: "bold 10pt sans-serif",
                    },
                    new go.Binding("text", "capacityValue"))),
        ),
    );
}

/***************************************** Models ********************************************************/
/*********************************************************************************************************/

function Model__AssignedSeating({ rows = 0, columns = 0 }) {
    var $ = go.GraphObject.make;
    var key = nodeDataArray.length++;
    var returnedNewItemData = Helpers__AddNewItem({ category: "AssignedSeating", parameters: { rows: rows, columns: columns } });

    return {
        category: "AssignedSeating",
        angle: 0,
        seat: `${"Seat" + 1}`,
        nodeDataArray: [returnedNewItemData],
    };
}

function Model__GeneralAdmission({ capacity = 0 }) {
    var $ = go.GraphObject.make;
    var key = this.nodeDataArray.length++;
    return {
        key: key,
        foot: "1",
        category: "GeneralAdmission",
        seat: "Seat2",
        capacity: "Capacity: ",
        capacityValue: capacity,
        img: "./assets/images/footprint.png",
        color: "lightblue",
        angle: 0
    };
}

/***************************************** Utility/Helpers Functions *************************************/
/*********************************************************************************************************/

function Helpers__findColumnDefinition({ nodeData = {}, column = 0 }) {
    var columns = nodeData.nodeDataArray[0].columnDefinitions;
    for (var i = 0; i < columns.length; i++) {
        if (columns[i].column === column) {
            // console.log("columns[i]", columns[i]);
            return columns[i];
        }
    }
    return null;
}

function Helpers__onSelectNode(node) {
    if (node.key !== undefined) {
        if (node.isSelected) {

            if (this.selectedNodesTable[node.key] === undefined)
                this.selectedNodesTable[node.key] = node.key;
            else
                delete this.selectedNodesTable[node.key];

            // node.angle = 60;
        } else {

            if (this.selectedNodesTable[node.key] === undefined)
                this.selectedNodesTable[node.key] = node.key;
            else
                delete this.selectedNodesTable[node.key];
        }

        if (Helpers__getObjectLength({ object: this.selectedNodesTable }) === 1) {
            this.rotatableNodeKey = Helpers__getObjectValues({ object: this.selectedNodesTable })[0];
            // this.rotatableNodePosition = node.position;
        }

        console.log("position: ", node.position);
        console.log("rotatableNodePosition: ", this.rotatableNodePosition);

        /*
         *   Condition 1: When a node get selected, this condition will trigger.
         *   Condition 2: When a user deselect all nodes.
         *   Other Conditions: Other cases get ignore.
         */
        if (Object.keys(this.selectedNodesTable).length === 1 && node.isSelected) {
            Helpers__HideOrShow({ elementID: "capacity" });
            Helpers__HideOrShow({ elementID: "selected" });
        } else if (Object.keys(this.selectedNodesTable).length === 0 && !node.isSelected) {
            Helpers__HideOrShow({ elementID: "capacity" });
            Helpers__HideOrShow({ elementID: "selected" });
        }
    } else {
        /*
         * This part will trigger when a user delete nodes.
         *   Reason: When nodes got deleted, onSelect method get called automatically.
         *           When onSelect get called, behind the scene {{node.key}} becomes 
         *           undefined. Even though user didn't selected any node after deletion.
         * These condition will trigger when user press delete or duplicate buttons.
         *   Condition 1: We used the value of user deletion action and then reset it.
         *   Condition 2: We used the value of user duplication action and then reset it.
         */
        if (this.wereNodesDelByUser) {
            Helpers__HideOrShow({ elementID: "capacity" });
            Helpers__HideOrShow({ elementID: "selected" });

            /*
             *   Get rid off user deletion action.
             */
            this.wereNodesDelByUser = false
        } else if (this.wereNodesDupByUser) {
            Helpers__HideOrShow({ elementID: "capacity" });
            Helpers__HideOrShow({ elementID: "selected" });

            /*
             *   Get rid off user duplication action.
             */
            this.wereNodesDupByUser = false
        }
    }
}

function Helpers__RemoveItems({ nodeDataArray = [], selectedNodesTable = {} }) {
    var array = [];
    if (selectedNodesTable !== undefined) {
        nodeDataArray.map((item) => {
            if (selectedNodesTable[item.key] !== undefined) {
                // nodeDataArray.splice(index, 1);
            } else {
                array.push(item);
            }
        });
        Helpers__clearSelectedNodesTable();
        console.log(this.selectedNodesTable);
    }
    /*
     *   Get rid off selected nodes.
     *   User deletion action got save.
     */
    this.wereNodesDelByUser = true;
    Helpers__clearSelectedNodesTable();
    return array;
}

function Helpers__DuplicateArray({ nodeDataArray = [] }) {
    var array = [];

    nodeDataArray.map((item) => {
        array.push(item);
    });

    return array;
}

function Helpers__GenerateSeats({ nodeDataArray = [], oldGroupKey = 0, newGroupKey = 0 }) {
    var array = Helpers__DuplicateArray({ nodeDataArray: nodeDataArray });
    array.map((item) => {
        if (oldGroupKey === item.group) {
            myDiagram.model.addNodeData({
                text: item.text,
                category: item.category,
                group: newGroupKey,
                color: item.color
            });
            console.log(item);
        }
    });
}

function Helpers__DuplicateItems({ nodeDataArray = [], selectedNodesTable = {} }) {
    var array = [];

    if (selectedNodesTable !== undefined) {
        nodeDataArray.map((item) => {

            if (selectedNodesTable[item.key] !== undefined) {
                switch (item.category) {
                    case "AssignedSeating":
                        var itemCopyKey = nodeDataArray.length++;
                        array.push({
                            key: itemCopyKey,
                            category: item.category,
                            nodeDataArray: item.nodeDataArray,
                            seat: item.seat
                        });
                        console.log(array);
                        break;
                    case "GeneralAdmission":
                        var itemCopyKey = nodeDataArray.length++;
                        array.push({
                            key: itemCopyKey,
                            foot: "1",
                            category: item.category,
                            seat: item.seat,
                            capacity: item.capacity,
                            capacityValue: item.capacityValue,
                            img: item.img,
                            color: item.color
                        });
                        break;
                    default:
                }
                console.log("Default Case: ");
            }
        });
        Helpers__clearSelectedNodesTable();
        console.log(this.selectedNodesTable);
    }

    /*
     *   Get rid off selected nodes.
     *   User duplication action got save.
     */
    Helpers__clearSelectedNodesTable();
    this.wereNodesDupByUser = true;
    return array;
}

function Helpers__getNodeData({ nodeDataArray = [], nodeKey = {} }) {
    var array = [];

    if (nodeKey !== undefined) {
        nodeDataArray.map((item) => {
            if (item.key === nodeKey) {
                array.push(item);
                return;
            }
        });
    } else {
        console.log("Helpers__getNodeData(): nodeKey is undefined.");
    }

    return array;
}

function Helpers__updateNodeData({ nodeDataArray = [], node = {} }) {
    var array = [];

    if (node !== undefined) {
        nodeDataArray.map((item) => {
            if (item.key === node.key) {
                array.push(node);
                return;
            } else {
                array.push(item);
            }
        });
    } else {
        console.log("Helpers__getNodeData(): nodeKey is undefined.");
    }

    return array;
}

function Helpers__clearSelectedNodesTable() {
    this.selectedNodesTable = {};
}

function Helpers__HideOrShow({ elementID = "" }) {
    var x = document.getElementById(elementID);
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}

function Helpers__HideOrShowCapacityMenu({ elementID = "" }) {
    var menuOptions = ["selected", "menu1", "menu2", "menu3", "menu4"];

    menuOptions = menuOptions.map((value) => {
        if (value === elementID) {
            document.getElementById(value).style.display = "block";
        } else {
            document.getElementById(value).style.display = "none";
        }
    });
}

function Helpers__HideOrShowCapacitySelected({ elementID = "" }) {
    var menuOptions = ["selected", "capacity",];

    menuOptions = menuOptions.map((value) => {
        if (value === elementID) {
            document.getElementById(value).style.display = "block";
        } else {
            document.getElementById(value).style.display = "none";
        }
    });
}

function Helpers__SetInputFieldValue({ elementID = "", value = "" }) {
    document.getElementById(elementID).value = value;
}

function Helpers__GetInputFieldValue({ elementID = "" }) {
    return document.getElementById(elementID).value;
}

function Helpers__AddNewItem({ category = "", parameters = {} }) {
    switch (category) {
        case "AssignedSeating":
            var columnsList = [];
            var rowsList = [];
            var key = this.nodeDataArray.length;
            console.log("key", key);

            for (var i = 0; i < parameters.columns; i++) {
                columnsList.push(
                    { column: i, text: `${i}` }
                );
            }

            for (var j = 0; j < parameters.rows; j++) {
                rowsList.push(
                    { columns: columnsList }
                );
            }

            return { // node
                key: key,
                columnDefinitions: columnsList,
                people: rowsList,
            };
        case "GeneralAdmission":
            console.log("GeneralAdmission: ");
        default:
            console.log("Default case: ");
    }
}

function Helpers__filterUndefinedFromArray({ array = [] }) {
    array = array.filter(function (item) {
        return item !== undefined;
    });
    return array;
}

function Helpers__getObjectLength({ object: object }) {
    return Object.keys(object).length;
}

function Helpers__getObjectValues({ object: object }) {
    return Object.values(object);
}